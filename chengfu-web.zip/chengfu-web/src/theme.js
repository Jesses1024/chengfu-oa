// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less
module.exports = {
  // 'primary-color': '#10e99b',
  'card-actions-background': '#f5f8fa',
  // '@icon-url': '"https://at.alicdn.com/t/font_751554_4jxpuw5kgze"',
};
