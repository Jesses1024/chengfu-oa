import React, { Component } from 'react';

class ChangeRecordTable extends Component {
  render() {
    return (
      <div />
    );
  }
}

export default ChangeRecordTable;
